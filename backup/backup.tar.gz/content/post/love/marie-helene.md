+++
date = "2015-12-24T12:35:25Z"
draft = true
title = "Marie-H"

+++

## Let me tell you...

...why I love Marie-H.

#### She's got fine cheeks!
Indeed she does. Makes me want to bite them most of the time.

#### She always ready for adventure!
Yep! Can't even seem to keep up at times :)

#### She whips up a mighty dish
And I take care of the dishes...

#### She loves her family
And love brings love

#### She's the one I'd marry
Over and over and over again... 

#### She makes me say and do all kinds of silly things
But it's allright, she's got my heart

#### C'est ma jolie
Et je pense a elle tout le temps
