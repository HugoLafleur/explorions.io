+++
date = "2015-12-23T12:38:07Z"
draft = true
title = "Victory (partial, yet significant)"

+++

### So... as it turns out

It just so happens that I've finally made the gohugo.io blogging engine work with docker infrastructure.

Below is the Dockerfile for the blog server...

```
FROM golang:latest
MAINTAINER Hugo Lafleur hugo.lafleur@gmail.com
ARG hugoTheme=hyde
EXPOSE 1313

RUN go get -u -v github.com/spf13/hugo
RUN hugo new site /blog

WORKDIR /blog/themes
RUN ln -s $hugoTheme current

WORKDIR /blog
CMD ["hugo", "server", "--buildDrafts", "--theme=current", "--bind=0.0.0.0", "--baseURL=http://52.91.65.121/", "--appendPort=false"]
```

...which essentially builds upon two other volume containers:
- One for the blog content
- One for the themes

The objective is to be able to evolve the theme without affecting data and vice versa.
