+++
date = "2015-12-24T12:01:33Z"
draft = true
title = "The Script!"
tags = [ "bash" ]
categories = [ "dev" ]
+++

So here's the script that I used to get started:

```bash
#!/bin/bash
DENV=$1
NAME=$2
THEME=$3
PORT=$4

docker run -d \
  -p $PORT:$PORT \
    --name $NAME \
    --volumes-from blogcontent \
    --volumes-from blogthemes \
    blog \
    server \
        --buildDrafts \
        --theme=$THEME \
        --bind=0.0.0.0 \
        --baseURL=http://$(docker-machine ip $DENV) \
        --appendPort=true \
        --port=$PORT
```

