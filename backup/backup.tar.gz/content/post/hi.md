+++
date = "2015-12-22T03:18:56Z"
draft = true
title = "hi"

+++

So I'm writing this first post in a 3rd container, only running vi upon Alpine Linux. . .
